#pragma once
#include "lab_m1/lab1/Tema1.h"
#include "components/simple_scene.h"
#include <vector>
using namespace std;
namespace m1 {
	class Tank : public gfxc::SimpleScene {

	public:
		
		Tank(glm::vec3 lower, glm::vec3 upper, char tankName[100], char cannon[100], class Tema1* tema1, int pozTankX, float rotAngle, char projectile[100]);
		~Tank();
		friend class Tema1;
	protected:
		struct projectile {
			glm::vec2 speed;
			glm::vec2 poz;
			float angleProj;
		};
		float tankX;
		float tankY;
		int domeCenterX;
		int domeCenterY;
		float angle;
		vector<VertexFormat> verticesT;
		vector<unsigned int> indicesT;
		vector<VertexFormat> verticesC;
		vector<unsigned int> indicesC;
		float rotateAngle;
		int widthTank;
		int heightTank;
		glm::vec2 speed;
		glm::vec2 poz;
		float angleProj;
		vector <projectile> projectiles;
	private:
		void initVeticesTank(glm::vec3 lower, glm::vec3 upper);
		void initIndicesTank();
		void initDomeTank(glm::vec3 upper);
		void updateTank(vector<float> height);
		void initCannon(class Tema1* tema1,char cannonName[100]);
		void initProjectile(char projectile[100], class Tema1* tema1);
		void addProjectile(glm::vec2 speed, glm::vec2 poz, float angle);
	};

}
