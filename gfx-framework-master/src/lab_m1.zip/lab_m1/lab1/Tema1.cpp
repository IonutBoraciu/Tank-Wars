#include <vector>
#include <iostream>

#include "lab_m1/lab3/transform2D.h"
#include "lab_m1/lab3/object2D.h"
#include "lab_m1/lab1/Tema1.h"
#include "lab_m1/lab1/Tank.h"
// for choosing an icon for the game
#include <stb/stb_image.h>
#include "core/window/window_object.h"
using namespace std;
using namespace m1;
/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */

vector<float> height;
float rotateAngle = 100;
Tema1::Tema1()
{
}


Tema1::~Tema1()
{
}

float generateFunction(int x) {
	float fct = 60 * sin(0.005 * x) + 30 * sin(0.03 *x) + 20 * sin(0.02*x) + 300;
	return fct;
}

void Tema1::initTerrain(char name[100]) {
	vector<VertexFormat> vertices;
	vector<unsigned int> indices;
	for (int i = 0; i < height.size(); i++) {
		vertices.push_back(VertexFormat(glm::vec3(i, height[i], 0), glm::vec3(0.54, 0.6, 0.35)));
		vertices.push_back(VertexFormat(glm::vec3(i, 0, 0), glm::vec3(0.54, 0.6, 0.35)));
	}
	for (int i = 0; i < height.size() - 1; i++) {
		indices.push_back(2 * i);
		indices.push_back(2 * i + 1);
		indices.push_back(2 * i + 2);
		indices.push_back(2 * i + 1);
		indices.push_back(2 * i + 2);
		indices.push_back(2 * i + 3);
	}

	if (meshes[name] == NULL) {
		Mesh* terrain = new Mesh(name);
		terrain->InitFromData(vertices, indices);
		AddMeshToList(terrain);
	}
	else {
		meshes[name]->InitFromData(vertices, indices);
	}

}

void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	widthScreen = resolution.x;
	heightScreen = resolution.y;
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);
	for (int i = 0; i < widthScreen + 50; i++) {
		height.push_back(generateFunction(i));
	}
	initTerrain("terrainStrip");

	tanks[0] = new Tank(glm::vec3(0.59, 0.52, 0.34), glm::vec3(0.75, 0.6, 0.4), "tank","cannon", this, 50,99.5,"projectile1");
	tanks[1] = new Tank(glm::vec3(0, 0.5, 0.5), glm::vec3(0.25, 0.5, 0.42), "tank2", "cannon2", this, widthScreen - 200, 101.75,"projectile2");
}


void Tema1::FrameStart()
{
	// Clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0.4f, 0.7f, 0.85f, 1.0f);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// Sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::addMeshToList(Mesh* mesh) {
	AddMeshToList(mesh);
}

void Tema1::explodeTerrain(float rotatedX, float rotatedY) {
	double step = 0.001;
	for (double angle = M_PI; angle < 2 * M_PI; angle += step) {
		int pozCx = rotatedX + (float)20 * cos(angle);
		float pozCy = rotatedY + (float)20 * sin(angle);
		if (pozCy < height[pozCx]) {
			height[pozCx] = pozCy;
		}
	}
	initTerrain("terrainStrip");
}

void Tema1::updateProjectiles(int tankPoz, float deltaTimeSeconds) {
	glm::mat3 modelMatrix;
	for (auto i = tanks[tankPoz]->projectiles.begin(); i < tanks[tankPoz]->projectiles.end();) {
		modelMatrix = glm::mat3(1);
		i->poz[0] += i->speed[0] * deltaTimeSeconds;
		i->poz[1] += i->speed[1] * deltaTimeSeconds;
		i->speed[1] -= 9.8 * 100 * deltaTimeSeconds;
		modelMatrix *= transform2D::Translate(i->poz[0], i->poz[1]);
		modelMatrix *= transform2D::Rotate(i->angleProj);
		modelMatrix *= transform2D::Translate(0, 15);
		RenderMesh2D(meshes["projectile1"], shaders["VertexColor"], modelMatrix);

		float rotatedX = i->poz[0] + 1 * cos(i->angleProj) - 15 * sin(i->angleProj);
		float rotatedY = i->poz[1] + 1 * sin(i->angleProj) + 15 * cos(i->angleProj);


		int check = 0;
		for (int j = 0; j < height.size() -1; j++) {
			if (rotatedX >= j && rotatedX <= j + 1) {
				if (rotatedY < height[j]) {
					explodeTerrain(rotatedX, rotatedY);
;					i = tanks[tankPoz]->projectiles.erase(i);
					check = 1;
					break;
				}
			}
		}
		if (!check) {
			if (rotatedX < 0) {
				i = tanks[tankPoz]->projectiles.erase(i);
			}
			else if (rotatedX > widthScreen) {
				i = tanks[tankPoz]->projectiles.erase(i);
			}
			else {
				i++;
			}

		}


	}
}

void Tema1::updateTerrain(float deltaTimeSeconds) {
	int checkTerrain = 0;
	for (int i = 0; i < height.size() - 2; i++) {
		if (fabs(height[i] - height[i + 1]) >= 3) {
			if (height[i] > height[i + 1]) {
				height[i] -= 50 * deltaTimeSeconds;
				height[i + 1] += 50 * deltaTimeSeconds;
				checkTerrain = 1;
			}
			else {
				height[i] += 50 * deltaTimeSeconds;
				height[i + 1] -= 50 * deltaTimeSeconds;
				checkTerrain = 1;
			}
		}
	}
	if (checkTerrain) {
		initTerrain("terrainStrip");
	}
}

void Tema1::Update(float deltaTimeSeconds)
{

	updateTerrain(deltaTimeSeconds);

	tanks[0]->updateTank(height);
	glm::mat3 modelMatrix = glm::mat3(1);
	RenderMesh2D(meshes["terrainStrip"], shaders["VertexColor"], modelMatrix);
	modelMatrix *= transform2D::Translate(tanks[0]->tankX, tanks[0]->tankY);
	modelMatrix *= transform2D::Rotate(tanks[0]->angle);
	RenderMesh2D(meshes["tank"], shaders["VertexColor"], modelMatrix);

	modelMatrix *= transform2D::Translate(0, 15);
	modelMatrix *= transform2D::Rotate(tanks[0]->rotateAngle);
	RenderMesh2D(meshes["cannon"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	tanks[1]->updateTank(height);
	modelMatrix *= transform2D::Translate(tanks[1]->tankX, tanks[1]->tankY);
	modelMatrix *= transform2D::Rotate(tanks[1]->angle);
	RenderMesh2D(meshes["tank2"], shaders["VertexColor"], modelMatrix);

	modelMatrix *= transform2D::Translate(0, 15);
	modelMatrix *= transform2D::Rotate(tanks[1]->rotateAngle);
	RenderMesh2D(meshes["cannon2"], shaders["VertexColor"], modelMatrix);

	updateProjectiles(0, deltaTimeSeconds);
	updateProjectiles(1, deltaTimeSeconds);
}

void Tema1::FrameEnd()
{
}

bool Tema1::checkIntersection() {
	bool check = true;
	float angle0 = tanks[0]->angle * M_PI / 180.0f;
	float angle1 = tanks[1]->angle * M_PI / 180.0f;
	float xOffset0 = (float)tanks[0]->tankX * cos(angle0) - (float)tanks[0]->tankY * sin(angle0);
	float yOffset0 = (float)tanks[0]->tankX * sin(angle0) + (float)tanks[0]->tankY * cos(angle0);

	float xOffset1 = (float)tanks[1]->tankX * cos(angle1) - (float)tanks[1]->tankY * sin(angle1);
	float yOffset1 = (float)tanks[1]->tankX * sin(angle1) + (float)tanks[1]->tankY * cos(angle1);
	float x = pow((xOffset0 - xOffset1), 2);
	float y = pow((yOffset0 - yOffset1), 2);
	float val = sqrt(x + y);
	int offset = tanks[0]->widthTank;
	if (val + 2 >= 20 + offset) {
		check = false;
	}

	return check;
}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{
	double limitLeft = 102.010933;
	double limitRight = 99.357399;
	if (window->KeyHold(GLFW_KEY_A)) {
		if (tanks[0]->tankX - 10 > 0) {
				tanks[0]->tankX -= 100 * deltaTime;
		}

	}
	else if (window->KeyHold(GLFW_KEY_D)) {
		if (tanks[0]->tankX + 20 < widthScreen) {
			bool check = checkIntersection();
			if (!check) {
				tanks[0]->tankX += 100 * deltaTime;
			}
 		}
	}

	if (window->KeyHold(GLFW_KEY_W)) {
		if(tanks[0]->rotateAngle <= limitLeft)
			tanks[0]->rotateAngle += 3 * deltaTime;
	}
	else if (window->KeyHold(GLFW_KEY_S)) {
		if (tanks[0]->rotateAngle >= limitRight)
			tanks[0]->rotateAngle -= 3 * deltaTime;
	}

	if (window->KeyHold(GLFW_KEY_LEFT)) {
		if (tanks[1]->tankX - 10 > 0) {
			bool check = checkIntersection();
			if (!check) {
				tanks[1]->tankX -= 100 * deltaTime;
			}
		}
	} else if (window->KeyHold(GLFW_KEY_RIGHT)) {
		if (tanks[1]->tankX + 20 < widthScreen) {
				tanks[1]->tankX += 100 * deltaTime;
		}
	}

	if (window->KeyHold(GLFW_KEY_UP)) {
		if (tanks[1]->rotateAngle <= limitLeft)
			tanks[1]->rotateAngle += 3 * deltaTime;
	}
	else if (window->KeyHold(GLFW_KEY_DOWN)) {
		if (tanks[1]->rotateAngle >= limitRight)
			tanks[1]->rotateAngle -= 3 * deltaTime;
	}
}


void Tema1::OnKeyPress(int key, int mods)
{
 // Add key press event
	if (key == GLFW_KEY_SPACE) {
		float amp = 400;
		glm::vec2 speed = glm::vec2((float)cos(tanks[0]->rotateAngle + tanks[0]->angle + M_PI / 2) * amp, (float)sin(tanks[0]->rotateAngle + tanks[0]->angle + M_PI / 2) * amp);
		if (tanks[0]->projectiles.size() <= 2) {
			tanks[0]->addProjectile(speed, glm::vec2(tanks[0]->tankX, tanks[0]->tankY), tanks[0]->angle);
		}
	}

	if (key == GLFW_KEY_ENTER) {
		float amp = 400;
		glm::vec2 speed = glm::vec2((float)cos(tanks[1]->rotateAngle + tanks[1]->angle + M_PI / 2) * amp, (float)sin(tanks[1]->rotateAngle + tanks[1]->angle + M_PI / 2) * amp);
		if (tanks[1]->projectiles.size() <= 2) {
			tanks[1]->addProjectile(speed, glm::vec2(tanks[1]->tankX, tanks[1]->tankY), tanks[1]->angle);
		}
	}
}


void Tema1::OnKeyRelease(int key, int mods)
{
 // Add key release event
}


void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
 // Add mouse move event
}


void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
 // Add mouse button press event
}


void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
 // Add mouse button release event
}


void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema1::OnWindowResize(int width, int height)
{
}
