#include <iostream>

#include "lab_m1/lab3/transform2D.h"
#include "lab_m1/lab3/object2D.h"
#include "lab_m1/lab1/Tank.h"
using namespace std;
using namespace m1;

Tank::Tank(glm::vec3 lower, glm::vec3 upper, char tankName[100],char cannon[100], class Tema1* tema1, int pozTankX, float rotAngle, char projectile[100]) {
	tankX = pozTankX;
	tankY = 0;
	domeCenterX = 20;
	domeCenterY = 15;
	angle = 0;
	rotateAngle = rotAngle;
	initVeticesTank(lower, upper);
	initDomeTank(upper);
	initIndicesTank();
	initCannon(tema1,cannon);
	initProjectile(projectile, tema1);
	Mesh* tank = new Mesh(tankName);
	tank->InitFromData(verticesT, indicesT);
	tema1->AddMeshToList(tank);
	speed = glm::vec2(0, 0);
	poz = glm::vec2(0, 0);
	
}

Tank::~Tank() {

}

void Tank::initProjectile(char projectile[100], class Tema1* tema1) {
	vector<VertexFormat> vertices;
	vector<unsigned int> indices;
	int radius = 2;
	int triangleNo = 1;
	int numberOfTriangles = 10;
	float angleStep = 2.5 * M_PI / numberOfTriangles;
	vertices.push_back(VertexFormat(glm::vec3(2, 2, 0), glm::vec3(0, 0, 0)));
	for (int i = 0; i < numberOfTriangles; i++) {
		float angle = i * angleStep;
		float x = 2 + 2 * cos(angle);
		float y = 2 + 2 * sin(angle);
		vertices.push_back(VertexFormat(glm::vec3(x, y, 0),glm::vec3(0,0,0)));
		if (i != 0) {
			indices.push_back(0);
			indices.push_back(triangleNo + i - 1);
			indices.push_back(triangleNo + i);
		}
	}
	Mesh* tank = new Mesh(projectile);
	tank->InitFromData(vertices, indices);
	tema1->AddMeshToList(tank);
}

void Tank::initVeticesTank(glm::vec3 lower, glm::vec3 upper) {
	verticesT.push_back(VertexFormat(glm::vec3(-20, 5, 0), upper)); // A
	verticesT.push_back(VertexFormat(glm::vec3(-15, 5, 0), lower)); // B
	verticesT.push_back(VertexFormat(glm::vec3(-15, 15, 0), upper)); // C
	verticesT.push_back(VertexFormat(glm::vec3(15, 15, 0), upper)); // D
	verticesT.push_back(VertexFormat(glm::vec3(20, 5, 0), lower)); // E
	verticesT.push_back(VertexFormat(glm::vec3(15, 5, 0), lower)); // F
	verticesT.push_back(VertexFormat(glm::vec3(10, 0, 0), lower)); // G
	verticesT.push_back(VertexFormat(glm::vec3(-10, 0, 0), lower)); // H
	verticesT.push_back(VertexFormat(glm::vec3(0, 15, 0), upper)); // I
	widthTank = 40 - 0;
	heightTank = 15 - 0;
}

void Tank::initIndicesTank() {
	indicesT.push_back(0);
	indicesT.push_back(2);
	indicesT.push_back(3);

	indicesT.push_back(0);
	indicesT.push_back(3);
	indicesT.push_back(4);

	indicesT.push_back(1);
	indicesT.push_back(7);
	indicesT.push_back(5);

	indicesT.push_back(7);
	indicesT.push_back(5);
	indicesT.push_back(6);
}

void Tank::initDomeTank(glm::vec3 upper) {
	int triangleNo = 9;
	int numberOfTriangles = 30;
	float angleStep = 2 * M_PI / numberOfTriangles;
	for (int i = 0; i < numberOfTriangles; i++) {
		float angle = i * angleStep;
		float x = 0 + 8 * cos(angle);
		float y = 15 + 8 * sin(angle);
		verticesT.push_back(VertexFormat(glm::vec3(x, y, 0), upper)); // I
		if (i != 0) {
			indicesT.push_back(8);
			indicesT.push_back(triangleNo + i - 1);
			indicesT.push_back(triangleNo + i);
		}
	}
}

void Tank::updateTank(vector<float> height) {
	for (int i = 0; i < height.size() - 1; i++) {
		if (tankX >= i && tankX < i + 1) {
			float t = (float)(tankX - i) / (i + 1 - i);
			tankY = height[i] - 0.5 + t * (height[i + 1] - height[i]);

			angle = atan2(height[i + 1] - height[i], i + 1 - i);
			if (tankY < 0) {
				tankY = 0;
				angle = 0;
			}
			break;
		}
	}
}

void Tank::initCannon(class Tema1* tema1, char cannonName[100]) {
	verticesC.push_back(VertexFormat(glm::vec3(0, 7.5, 0), glm::vec3(0, 0, 0))); // A
	verticesC.push_back(VertexFormat(glm::vec3(0, 22.5, 0), glm::vec3(0, 0, 0))); // B
	verticesC.push_back(VertexFormat(glm::vec3(3, 22.5, 0), glm::vec3(0, 0, 0))); // C
	verticesC.push_back(VertexFormat(glm::vec3(3, 7.5, 0), glm::vec3(0, 0, 0))); // D
	indicesC.push_back(0);
	indicesC.push_back(1);
	indicesC.push_back(2);

	indicesC.push_back(0);
	indicesC.push_back(3);
	indicesC.push_back(2);

	Mesh* tank = new Mesh(cannonName);
	tank->InitFromData(verticesC, indicesC);
	tema1->AddMeshToList(tank);
}

void Tank::addProjectile(glm::vec2 speed, glm::vec2 poz , float angle) {
	projectiles.push_back(projectile{ speed,poz,angle });
}
